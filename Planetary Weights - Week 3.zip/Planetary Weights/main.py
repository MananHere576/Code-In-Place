"""
Prompts the user for a weight on Earth
and a planet (in separate inputs). Then 
prints the equivalent weight on that planet.

Note: Assumes planet name is typed with the first letter capitalized.
"""

def main():
    # Dictionary of planet gravitational constants relative to Earth
    gravity_factors = {
        "Mercury": 0.376,
        "Venus": 0.889,
        "Mars": 0.378,
        "Jupiter": 2.36,
        "Saturn": 1.081,
        "Uranus": 0.815,
        "Neptune": 1.14
    }

    try:
        earth_weight = float(input("Enter a weight on Earth: "))
        planet = input("Enter a planet: ")

        if planet in gravity_factors:
            planet_weight = round(earth_weight * gravity_factors[planet], 2)
            print(f"The equivalent weight on {planet}: {planet_weight}")
        else:
            print("That planet is not supported. Please enter a valid planet name (capitalized).")

    except ValueError:
        print("Invalid input. Please enter a numeric value for weight.")

if __name__ == "__main__":
    main()
